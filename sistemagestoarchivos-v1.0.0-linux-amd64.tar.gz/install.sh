#!/bin/bash
chmod +x sistemagestoarchivos
sudo mv sistemagestoarchivos /usr/local/bin/
echo "✅ Instalado en /usr/local/bin"